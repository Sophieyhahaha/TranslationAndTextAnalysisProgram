import 'dart:convert';
import 'dart:ffi';
import 'dart:io';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';

import 'package:file_picker/file_picker.dart';
import 'package:flutter_markdown/flutter_markdown.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
// import 'package:tesseract_ocr/tesseract_ocr.dart';
import 'package:markdown/markdown.dart' as md;
import 'package:file_picker/file_picker.dart';
// import 'package:tesseract_ocr/tesseract_ocr.dart';
// import 'package:web_socket_channel/io.dart';

class AnalysisTab extends StatefulWidget {
  static const title = 'Text Analysis';
  static const icon = Icon(CupertinoIcons.doc_text_search);

  @override
  _AnalysisTab createState() => _AnalysisTab();
}

class _AnalysisTab extends State<AnalysisTab> {
  final inputController = TextEditingController();
  // final outputController = TextEditingController();
  bool _scanning = false;
  String _extractText = '';
  int _scanTime = 0;
  String _response = '';

  @override
  void dispose() {
    // Clean up the controller when the widget is disposed.
    inputController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      appBar: AppBar(
        title: Text('Text Analysis'),
      ),
      body: Padding(
          padding: const EdgeInsets.all(0.0),
          child: SingleChildScrollView(
              child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: <Widget>[
              Stack(
                alignment: Alignment(0.89, 0.88),
                fit: StackFit.loose,
                children: <Widget>[
                  Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: TextField(
                      controller: inputController,
                      maxLines: 10, //15
                      decoration: InputDecoration(
                        hintText: "Input text ...",
                        border: OutlineInputBorder(),
                      ),
                    ),
                  ),
                  // Positioned(
                  //     left: 16,
                  //     child: IconButton(
                  //       // Text('Select image'),
                  //       icon: Icon(
                  //         CupertinoIcons.camera_rotate,
                  //         size: 30.0,
                  //       ),
                  //       onPressed: () async {
                  //         var file = await FilePicker.platform
                  //             .pickFiles(type: FileType.image);

                  //         var watch = Stopwatch()..start();
                  //         print(file.files.single.path);
                  //         _extractText = await TesseractOcr.extractText(
                  //             file.files.single.path);
                  //         inputController.text = _extractText;
                  //         _scanTime = watch.elapsedMilliseconds;
                  //       },
                  //     )),
                  Positioned(
                      right: 13,
                      child: IconButton(
                          icon: Icon(CupertinoIcons.delete_left, size: 30.0),
                          onPressed: () {
                            inputController.text = "";
                            setState(() {});
                          }))
                ],
              ),

              SizedBox(height: 10),
              Container(
                width: 350,
                height: 30,
                child: OutlineButton(
                  borderSide: BorderSide(
                    width: 1,
                    color: Colors.lightBlue,
                  ),
                  child: Text(
                    "Analyze",
                    style: TextStyle(
                      color: Colors.lightBlue.shade800,
                    ),
                  ),
                  onPressed: () async {
                    // 123.60.47.18
                    // var socket = await Socket.connect("119.3.156.106", 6666);
                    _scanning = true;
                    setState(() {});
                    var socket = await Socket.connect("47.89.154.218", 80);
                    socket.writeln("1" + inputController.text);
                    await socket.flush(); //发送
                    //读取返回内容
                    // _response = await socket.transform(utf8.decoder).join();
                    _response = await utf8.decoder.bind(socket).join();
                    _scanning = false;
                    setState(() {});
                    // print(_response);
                    await socket.close();
                  },
                ),
              ),
              SizedBox(
                height: 20,
              ),
              // Container(
              //   padding: const EdgeInsets.all(26.0),
              //   width: 400,
              //   child: Text(_response, style: TextStyle(fontSize: 16.0)),
              // ),
              _scanning
                  ? SpinKitCircle(
                      color: Colors.lightBlue,
                    )
                  : Container(
                      alignment: Alignment.center,
                      height: 300,
                      child: Markdown(
                        padding: const EdgeInsets.all(26.0),
                        controller: ScrollController(),
                        selectable: true,
                        data: _response,
                        extensionSet: md.ExtensionSet(
                          md.ExtensionSet.gitHubFlavored.blockSyntaxes,
                          [
                            md.EmojiSyntax(),
                            ...md.ExtensionSet.gitHubFlavored.inlineSyntaxes
                          ],
                        ),
                      ),
                    ),
              SizedBox(
                height: 100,
              )
            ],
          ))),
      // floatingActionButton: FloatingActionButton(
      //   // When the user presses the button, show an alert dialog containing
      //   // the text that the user has entered into the text field.
      //   onPressed: () {
      //     showDialog(
      //       context: context,
      //       builder: (context) {
      //         return AlertDialog(
      //           // Retrieve the text the that user has entered by using the
      //           // TextEditingController.
      //           content: Text(inputController.text),
      //         );
      //       },
      //     );
      //   },
      //   tooltip: 'Show me the text!',
      //   child: Icon(Icons.text_fields),
      // ),
      // floatingActionButtonLocation: FloatingActionButtonLocation.miniStartTop,
    );
  }
}
