import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'single_screen.dart';
import 'analysis_tab.dart';
import 'Translation_tab.dart';

// void main() => runApp(XiaowenAPP());

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'SingleScreen',
      theme: ThemeData(
        primaryColor: Colors.blue,
      ),
      home: SingleScreen(),
      routes: <String, WidgetBuilder> {
        '/NewPage' : (context) => XiaowenAPP()
      },
    );
  }
}

class XiaowenAPP extends StatelessWidget {
  @override
  Widget build(context) {
    return GestureDetector(
      onTap: () {
        FocusScopeNode currentFocus = FocusScope.of(context);
        if (!currentFocus.hasPrimaryFocus && currentFocus.hasFocus) {
          FocusManager.instance.primaryFocus.unfocus();
        }
      },
      child: MaterialApp(
        title: 'Text Processing APP',
        theme: ThemeData(
          primarySwatch: Colors.lightBlue,
        ),
        darkTheme: ThemeData.dark(),
        builder: (context, child) {
          return CupertinoTheme(
            data: CupertinoThemeData(),
            child: Material(child: child),
          );
        },
        home: XiaowenHomePage(),
      ),
    );
  }
}

class XiaowenHomePage extends StatefulWidget {
  @override
  _XiaowenHomePageState createState() => _XiaowenHomePageState();
}

class _XiaowenHomePageState extends State<XiaowenHomePage> {
  //final analysisTabKey = GlobalKey();

  Widget _buildIosHomePage(BuildContext context) {
    return CupertinoTabScaffold(
      tabBar: CupertinoTabBar(
        items: [
          BottomNavigationBarItem(
              label: AnalysisTab.title, icon: AnalysisTab.icon),
          BottomNavigationBarItem(
            label: TranslationTab.title,
            icon: TranslationTab.icon,
          ),
        ],
      ),
      tabBuilder: (context, index) {
        switch (index) {
          case 0:
            return CupertinoTabView(
              defaultTitle: AnalysisTab.title,
              builder: (context) => AnalysisTab(),
            );
          case 1:
            return CupertinoTabView(
              defaultTitle: TranslationTab.title,
              builder: (context) => TranslationTab(),
            );
          default:
            assert(false, "Unexpected tab");
            return SizedBox.shrink();
        }
      },
    );
  }

  @override
  Widget build(context) {
    return _buildIosHomePage(context);
  }
}
