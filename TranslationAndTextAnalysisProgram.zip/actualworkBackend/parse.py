import sys
import spacy
import torch
from pytorch_pretrained_bert import BertTokenizer, BertForMaskedLM

bert_version = 'bert-base-uncased'

def extract_cl(tokens, root_idx):
    n_token = len(tokens)

    root = tokens[root_idx]
    heads = [root]
    ids = [root_idx]

    while True:
        flag = True
        for idx in range(n_token):
            if tokens[idx].head in heads and idx not in ids:
                heads.append(tokens[idx])
                ids.append(idx)
                flag = False

        if flag:
            break

    ids.sort()

    return ' '.join([tokens[idx].text for idx in ids])

def parse_cl(tokens, root_idx):

    S, O, V = None, None, tokens[root_idx]
    P, A_S, A_O, AD = None, None, None, None

    for token in tokens:
        if token.dep_ == 'nsubj' and token.head == V:
            S = token
        elif token.dep_ == 'dobj'and token.head == V:
            O = token
        elif token.dep_ == 'attr' and token.head == V:
            P = token # Biao Yu
        elif token.dep_ == 'advmod' and token.head == V:
            AD = token # Zhuang Yu

    for token in tokens:
        if token.dep_ == 'amod' and token.head == S:
            A_S = token # Ding Yu of Zhu Yu
        elif token.dep_ == 'amod' and token.head == O:
            A_O = token # Ding Yu of Bing Yu

    return [S, O, V, P, A_S, A_O, AD]


def parse(data, nlp):
    print("********************************Parsing****************************************")
    # nlp = model_prase
    tokenizer = BertTokenizer.from_pretrained(bert_version)
    #print(nlp)
    sent = data
    if(sent == ''):
        return ''
    print(sent)
    tokens = nlp(sent)
    print('tokens:{}'.format(tokens))
    ACLs, RCLs, CONJs = [], [], []

    tokens_md = tokenizer.tokenize(sent)
    tokens_md[0] = tokens_md[0].capitalize()

    for idx, token in enumerate(tokens):
        if token.dep_ == 'ROOT':
            V, V_idx = token, idx

    for idx, token in enumerate(tokens):
        if token.dep_ == 'relcl':
            RCLs.append((token, idx))
    
    for idx, token in enumerate(tokens):
        if token.dep_ == 'advcl':
            ACLs.append((token, idx))

    for idx, token in enumerate(tokens):
        if token.dep_ == 'conj':
            CONJs.append((token, idx))

    RCL, RCL_ids = [item[0] for item in RCLs], [item[1] for item in RCLs]
    ACL, ACL_ids = [item[0] for item in ACLs], [item[1] for item in ACLs]
    CONJ, CONJ_ids = [item[0] for item in CONJs], [item[1] for item in CONJs]

    S, O, V, P, AD, A_S, A_O = parse_cl(tokens, V_idx)

    result = []

    if not S:
        result.append(':point_right:  Subject: '+'None')
    else:
        result.append(':point_right:  Subject: '+S.text)
        for i in range(len(tokens_md)):
            if(tokens_md[i] == S.text):
                tokens_md[i] = "**"+ S.text + "**"

    if not O:
        result.append(':point_right:  Object: '+'None')
    else:
        result.append(':point_right:  Object: '+O.text)
        for i in range(len(tokens_md)):
            if(tokens_md[i] == O.text):
                tokens_md[i] = '*'+ O.text + '*' 
    
    if not V:
        result.append(':point_right:  Verb: '+'None')
    else:
        result.append(':point_right:  Verb: '+V.text)
        for i in range(len(tokens_md)):
            if(tokens_md[i] == V.text):
                tokens_md[i] = '{'+ V.text + '}'

    if P:
        result.append(':point_right:  Predicative: '+P.text)

    if AD:
        result.append(':point_right:  Adverbial: '+AD.text)
        for i in range(len(tokens_md)):
            if(tokens_md[i] == AD.text):
                tokens_md[i] = '['+ AD.text + ']'

    if A_O:
        result.append(':point_right:  Attributive of object: '+A_O.text)
     
    if A_S:
        result.append(':point_right:  Attributive of adverbial: '+A_S.text)

    if (len(RCL_ids)>0):
        RCL_text = ''
        for RCL_idx in RCL_ids:
            tmp = extract_cl(tokens, RCL_idx)
            RCL_text = tmp
            RCL_list = tmp.split(' ')
        result.append(':point_right:  Attributive clause: '+RCL_text) 
        for i in range(len(tokens_md)):
            if(tokens_md[i] == RCL_list[0] and tokens_md[i+1] == RCL_list[1]):
                tokens_md[i] = '('+ RCL_list[0]
            if(tokens_md[i] == RCL_list[-1] and tokens_md[i-1] == RCL_list[-2]):
                tokens_md[i] = RCL_list[-1] + ')'

    
    if (len(ACL_ids)>0):
        ACL_text = ''
        ACL_list = []
        for ACL_idx in ACL_ids:
            tmp = extract_cl(tokens, ACL_idx)
            ACL_text = tmp
            ACL_list = tmp.split(' ')
        result.append(':point_right:  Adverbial clause: '+ACL_text)
        for i in range(len(tokens_md)):
            if(tokens_md[i] == ACL_list[0] and tokens_md[i+1] == ACL_list[1]):
                tokens_md[i] = '['+ ACL_list[0]
            if(tokens_md[i] == ACL_list[-1] and tokens_md[i-1] == ACL_list[-2]):
                tokens_md[i] = ACL_list[-1] + ']'

    if (len(CONJ_ids)>0):
        CONJ_text = ''
        CONJ_list = []
        for CONJ_idx in CONJ_ids:
            tmp = extract_cl(tokens, CONJ_idx)
            CONJ_text = tmp
            CONJ_list = tmp.split(' ')
        result.append(':point_right:  Conjunction: '+CONJ_text)        
        for i in range(len(tokens_md)):
            if(tokens_md[i] == CONJ_list[0] and tokens_md[i+1] == CONJ_list[1]):
                tokens_md[i] = "'"+ CONJ_list[0]
            if(tokens_md[i] == CONJ_list[-1] and tokens_md[i-1] == CONJ_list[-2]):
                tokens_md[i] = CONJ_list[-1] + "'"

    mesg =''
    for r in result:
        mesg = mesg + r +'\\\n' + '\\\n'
    
    # mesg = mesg + '\\\n' #+ ':point_right:  '

    # for word in tokens_md:
    #     mesg = mesg + word + ' '

    return mesg.strip()
