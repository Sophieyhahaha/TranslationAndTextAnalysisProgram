import socketserver
import torch #analysis
from pytorch_pretrained_bert import BertTokenizer, BertForMaskedLM #analysis
from googletrans import Translator
import googletrans
import sys
import spacy  #analysis
from parse import * # analysis  

ip_port=("0.0.0.0",80)
model_prase = spacy.load('en_core_web_sm')
translator = Translator()

print("Model loaded!")



class Myserver(socketserver.BaseRequestHandler):
    def handle(self):
        print('*********************Handle*****************************')
        print("conn is:", self.request)
      
        while True:
            try:
                # self.request is the TCP socket connected to the client
                self.data = self.request.recv(1024).strip()    #.strip()字符串操作
                self.data = self.data.decode("utf-8")
                print("{} wrote: {}".format(self.client_address[0], self.data))
                flag = self.data[0]
                self.data = self.data[1:]

                if(flag == '0'):
                    result = translator.translate(self.data, dest= 'zh-cn')
                    #'en': 'english'；'fr': 'french'； 'zh-cn': 'chinese
                    return_str = result.text
                    self.request.sendall(return_str.encode("utf-8"))
                
                elif(flag == '1'):
                    sent = self.data
                    return_str = parse(self.data, model_prase)
                    self.request.sendall(return_str.encode("utf-8"))
                
                else:
                    self.request.send("Please give 1/0.".encode("utf-8"))
                #self.request.sendall(self.data.upper())

                print("Send back finished.")
            except Exception as e:
                print(e)
                break

if __name__ == "__main__":
    with socketserver.TCPServer(ip_port, Myserver) as server:
        server.serve_forever() 



